package com.file.firebasenotificationdemo.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import com.file.firebasenotificationdemo.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FirebaseNotification : FirebaseMessagingService(){
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        var title: String = message.notification!!.title!!
        var body: String = message.notification!!.body!!
        var channelID = "My_Notification"

        var notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        var channel: NotificationChannel = NotificationChannel(channelID, channelID, NotificationManager.IMPORTANCE_HIGH)
        notificationManager.createNotificationChannel(channel)

        var notificationBuilder = Notification.Builder(this, channelID)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setAutoCancel(true)

        if(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "Permission Not Granted!", Toast.LENGTH_SHORT).show()
            return
        }
        NotificationManagerCompat.from(this).notify(1, notificationBuilder.build())
    }
}